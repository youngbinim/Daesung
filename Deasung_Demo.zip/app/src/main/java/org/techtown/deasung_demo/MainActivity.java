package org.techtown.deasung_demo;

import static org.techtown.ifmmanager.IfmPkt.ifmPacketParsing;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.techtown.ifmmanager.FWDown;
import org.techtown.ifmmanager.IFMControllerInterface;
import org.techtown.ifmmanager.IFMManager;
import org.techtown.ifmmanager.IfmPkt;
import org.techtown.ifmmanager.Utils;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button button_selftest, button_fwversion, button_fwdown, button_clear;
    TextView textView,textView2,textView3;
    IFMManager ifmManager;
    Context mContext;
    FWDown fwDown;
    String strFilepath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_selftest = findViewById(R.id.btn_selftest);
        button_fwversion = findViewById(R.id.btn_fw_version);
        button_fwdown = findViewById(R.id.btn_fwdown);
        button_clear = findViewById(R.id.btn_textclear);

        textView = findViewById(R.id.tx_result);
        textView2 = findViewById(R.id.tx_result2);
        textView3 = findViewById(R.id.tx_result3);

        button_selftest.setOnClickListener(this);
        button_fwversion.setOnClickListener(this);
        button_fwdown.setOnClickListener(this);
        button_clear.setOnClickListener(this);

        mContext = this;

        ifmManager = new IFMManager();
        ifmManager.initIfmController(mContext,ifmRecvCallback);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btn_fw_version:{
                ifmManager.reqIFM(IfmPkt.TRD_TYPE_REQ_FW_INFO);
                break;
            }
            case R.id.btn_selftest:{
                ifmManager.reqIFM(IfmPkt.TRD_TYPE_REQ_SELF_PROTECTION);
                break;
            }
            case R.id.btn_fwdown:{
                ifmManager.PowerOffRdi();
                fwDown = new FWDown();
                fwDown.deviceMsrOpen();

                strFilepath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/PM1100LH_FW_KCP_v03.03_RELEASE_07.Apr.2021.bin";
                fwDown = new FWDown(mContext, new File(strFilepath), fwHandler);
                fwDown.execute();


                break;
            }
            case R.id.btn_textclear:{
                textView.setText("");
                textView2.setText("");
                textView3.setText("");
                break;
            }
        }
    }

    IFMControllerInterface.OnIfmRecvCallback ifmRecvCallback = new IFMControllerInterface.OnIfmRecvCallback() {
        @Override
        public void onIfmRecvCallback(int callbackMsg, byte[] recvBuf) {
            if(recvBuf != null){
                if(callbackMsg == Utils.IFM_RESP_RECEIVE_OK){
                    LinkedHashMap<String, String> inmap;

                    inmap = ifmPacketParsing(recvBuf);
                    byte trdtype = recvBuf[3];

                    if(inmap != null){
                        switch(trdtype){
                            case IfmPkt.TRD_TYPE_REQ_FW_INFO:{           // FW INFO
                                String fwVersion = inmap.get(IfmPkt.MapData.Mapkey_0A[0]);      // Fw Version
                                //String fwBuildDate = inmap.get(IfmPkt.MapData.Mapkey_0A[1]);  // Build Date
                                //String fwBuildType = inmap.get(IfmPkt.MapData.Mapkey_0A[2]);  // Build Type
                                textView2.setTextColor(getRandomColor());
                                textView2.setText(fwVersion);
                                break;
                            }
                            case IfmPkt.TRD_TYPE_REQ_SELF_PROTECTION:{          // 무결성 점검
                                String selftest = inmap.get(IfmPkt.MapData.Mapkey_A1[0]);       // 무결성 검증(성공/실패)
                                textView.setTextColor(getRandomColor());
                                textView.setText(selftest);
                                break;
                            }
                            default:{
                                break;
                            }
                        }
                    }
                }
            }
            else{
                if(callbackMsg == Utils.IFM_RESP_RECEIVE_FAIL){
                    textView.setText("Receive Fail");
                }
                else if(callbackMsg == Utils.IFM_RESP_RECEIVE_TIMEOUT){
                    textView.setText("Receive Timeout");
                }
            }
        }
    };

    public int getRandomColor(){
        Random rnd = new Random();
        return Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
    }

    private Handler fwHandler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(@NonNull Message msg) {
            if(msg.what == 1){
                textView3.setTextColor(getRandomColor());
                textView3.setText("업데이트 완료");
            }else if(msg.what == 0){
                textView3.setTextColor(getRandomColor());
                textView3.setText("업데이트 실패");
            }

            ifmManager.PowerOnRdi();
        }
    };
}