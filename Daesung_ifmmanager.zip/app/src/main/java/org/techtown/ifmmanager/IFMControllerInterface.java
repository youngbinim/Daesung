package org.techtown.ifmmanager;

import android.content.Context;


public class IFMControllerInterface {
    public interface OnIFMControllerInterface{
         void PowerOnRdi();

         void PowerOffRdi();

         void initIfmController(Context context, OnIfmRecvCallback ifmRecvCallback);

         void reqIFM(byte trdType);
    }

    public interface OnIfmRecvCallback{
        public void onIfmRecvCallback(int callbackMsg, byte[] recvBuf);
    }
}
