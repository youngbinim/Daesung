package org.techtown.ifmmanager;

import android.content.Context;
import android.os.Handler;
import android.os.Message;

import device.sdk.MsrManager;

// on / off // read / write
public class RdiManager extends MsrManager {

    private final String TAG = RdiManager.class.getSimpleName();

    private static Context mContext;
    public static int ENABLE = 1;
    public static int DISABLE = 0;

    public boolean  mIsRdiOpened = false;
    private boolean mfRcvThread = false;
    private Handler mIfmManagerHandler = null;  //read thread callback


    public final int STEP_STX  = 1;
    public final int STEP_ACK  = 2;
    public final int STEP_DLE  = 3;
    public final int STEP_LEN  = 4;
    public final int STEP_LEN2 = 5;
    public final int STEP_ETX  = 6;
    public final int STEP_LRC  = 7;

    public int rcvSTEP;
    public int pktDataLen;

    public RdiManager(){

    }

    public RdiManager(Context context) {
        mContext = context;
    }

    public int setEnable(int enable){
        return rdiSetEnable(enable);
    }

    public int isEnabled(){
        return rdiIsEnabled();
    }

    public int read(byte[] data, int length){
        return rdiRead(data, length);
    }

    public void powerDown(){

        if(rdiClose() == 0)
            mIsRdiOpened = false;
    }

    public boolean powerOn(){
        int opend = -1;

        try{
            opend = rdiOpen();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(opend == 0){
            mIsRdiOpened = true;
        }else if(opend == -1){
            mIsRdiOpened = false;
        }

        return mIsRdiOpened;
    }

    public int clear() {

        return rdiClear();
    }

    public byte[]   backupCmd;

    public int write(byte[] data, int length) {

        byte[]      padingData = setPaddingData(data);

        // firmware reboot에 대비해 backup을 해둔다.
        backupCmd = new byte[padingData.length];
        System.arraycopy(padingData, 0, backupCmd, 0, backupCmd.length);

        mfRcvThread = false;
        return rdiWrite(padingData, padingData.length);
    }

    public byte[] setPaddingData(byte[] data)
    {
        int     length = data.length;

        if ((length % 8) == 7) {
            length++;
        }

        length += (8 - (length % 8)) + 11;

        byte[]      returnData = new byte[length];

        for (int i = 0; i < length; i++) {
            if (i >= data.length)
                returnData[i] = (byte) 0xFF;
            else
                returnData[i] = data[i];
        }

        return returnData;
    }
    public void readData(Handler msrHandler, int timeout)
    {
        mIfmManagerHandler = msrHandler;

        new Thread(new ReadThread(timeout)).start();

        return;
    }

    private class ReadThread implements Runnable{

        int mTimeout = 0;
        final long      TIME_INTERVAL = 100;

        public class RecvPkt{
            byte[] Buffer;
            int index;

            RecvPkt(){
                Buffer = new byte[Utils.MAX_ICREADER_PACKET_SIZE];
                index = 0;
            }

        }

        RecvPkt recvPkt = new RecvPkt();


        ReadThread(int timeout){
            mfRcvThread = true;
            mTimeout = timeout;
        }
        @Override
        public void run() {
            int ReadDataSize = 0;
            long rtime = 0L;
            long timeout = mTimeout;
            byte[] rcvBuff = new byte[Utils.MAX_ICREADER_PACKET_SIZE];
            byte[] readPktBuf = null;
            int retCheckPacket = 0;

            rcvSTEP = STEP_STX;

            while(rtime < timeout && mfRcvThread && !Thread.interrupted()){
                try{
                    Thread.sleep(TIME_INTERVAL);
                    rtime += TIME_INTERVAL;

                    if(rtime > timeout){
                        sendHandleMsgToIfmManager(null, Utils.IFM_RESP_RECEIVE_TIMEOUT);
                        mfRcvThread = false;
                        continue;
                    }
                }catch(InterruptedException e){
                    e.printStackTrace();
                    mfRcvThread = false;
                }

                ReadDataSize = read(rcvBuff,rcvBuff.length);

                if(ReadDataSize == -1){
                    sendHandleMsgToIfmManager(rcvBuff,Utils.IFM_RESP_RECEIVE_FAIL);
                    mfRcvThread = false;
                    continue;
                }

                if(ReadDataSize > 0){
                    retCheckPacket = CheckRcvPacket(rcvBuff,ReadDataSize);

                    if(retCheckPacket < 0){
                        sendHandleMsgToIfmManager(null, Utils.IFM_RESP_RECEIVE_FAIL);
                    }else if(retCheckPacket > 0){
                        readPktBuf = new byte[retCheckPacket];
                        System.arraycopy(recvPkt.Buffer,0,readPktBuf,0,recvPkt.index);

                        sendHandleMsgToIfmManager(readPktBuf,Utils.IFM_RESP_RECEIVE_OK);
                    }
                }

                if(retCheckPacket != 0){
                    mfRcvThread = false;
                    break;
                }

            }

            return;
        }

        public int CheckRcvPacket(byte [] src, int srcLen){
            int i = 0;
            int retVal = 0;
            while(i < srcLen){
                recvPkt.Buffer[recvPkt.index] = src[i];
                recvPkt.index %= Utils.MAX_ICREADER_PACKET_SIZE;

                switch(rcvSTEP)
                {
                    case STEP_STX: {
                        if(src[i] == 0x02){
                            recvPkt.index = 0;
                            recvPkt.Buffer[recvPkt.index] = src[i];
                            rcvSTEP = STEP_LEN;
                        }else if(src[i] == 0x10){
                            rcvSTEP = STEP_ACK;
                        }
                        break;
                    }
                    case STEP_ACK: {
                        if(src[i] == 0x06){
                            i++;

                            while(i < srcLen){
                                if(src[i] == 0x10 || src[i] == 0x06){
                                    i++;
                                    continue;
                                }else{
                                    break;
                                }
                            }

                            rdiWrite(backupCmd, backupCmd.length);
                        }

                        recvPkt.index = 0;
                        rcvSTEP = STEP_STX;
                        break;
                    }
                    case STEP_LEN: {
                        rcvSTEP = STEP_LEN2;
                        break;
                    }
                    case STEP_LEN2:{
                        pktDataLen = Utils.checkLength(new byte[]{recvPkt.Buffer[1], recvPkt.Buffer[2]});

                        if(pktDataLen > (Utils.MAX_ICREADER_PACKET_SIZE - 3)){
                            rcvSTEP = STEP_STX;
                        }else{
                            rcvSTEP = STEP_ETX;
                        }
                        break;
                    }
                    case  STEP_ETX:{
                        if(pktDataLen + 2 == recvPkt.index){
                            if(src[i] == 0x03){
                                rcvSTEP = STEP_LRC;
                            }else{
                                retVal = -2;
                            }
                        }
                        break;
                    }
                    case STEP_LRC:{
                        byte lrc = IfmMakePkt.calcLRC(recvPkt.Buffer,1, recvPkt.index);

                        if(lrc == src[i] || (lrc ^ (byte)0x02) == src[i]){
                            retVal = i;
                        }else{
                            retVal = -1;
                        }

                        break;
                    }
                    default:{
                        retVal = -3;
                        break;
                    }
                }

                if(retVal != 0){
                    i = srcLen;
                    continue;
                }

                i++;
                recvPkt.index++;
            }

            return retVal;
        }
    }

    public void sendHandleMsgToIfmManager(byte []recvData, int state){
        if(mIfmManagerHandler == null){
            return ;
        }

        Message obtainMsg =mIfmManagerHandler.obtainMessage();

        obtainMsg.what = state;

        if(state == Utils.IFM_RESP_RECEIVE_OK){
            obtainMsg.obj = recvData;
        }

        mIfmManagerHandler.sendMessage(obtainMsg);
        mIfmManagerHandler = null;

        return;
    }
}
