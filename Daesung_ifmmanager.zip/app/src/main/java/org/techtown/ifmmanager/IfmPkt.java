package org.techtown.ifmmanager;

import java.util.LinkedHashMap;

public class IfmPkt {
    public static final byte CMD_FS = (byte)0x1c;
    public static byte[] FS = new byte[]{CMD_FS};

    public static final byte TRD_TYPE_REQ_SELF_PROTECTION       = (byte)0xA1;   // 무결성 검증 요청
    public static final byte TRD_TYPE_REQ_FW_INFO               = (byte)0x0A;   // FW 정보 읽기(version, build data, build type)

    public static LinkedHashMap<String, String> mCallbackMap = null;

    public static class MapData{
        public static final String self_protection = "self_protection";

        public static String[] Mapkey_A1 = new String[]{
                self_protection
        };

        public static final String fwversion = "fwversion";
        public static final String fwBuildDate = "fwBuildDate";
        public static final String fwBuildType = "fwBuildType";

        public static String[] Mapkey_0A = new String[]{
                fwversion,
                fwBuildDate,
                fwBuildType
        };


    }

    /**< get Response Code from IFM response */
    public static String getRespCode(byte[] data)
    {
        byte[]  resultBuf=new byte[2];
        int     strPos= IfmMakePkt.RdiFormat.STX_LEN +
                IfmMakePkt.RdiFormat.DATA_LENGTH_LEN +
                IfmMakePkt.RdiFormat.COMMANDID_LEN;

        System.arraycopy(data, strPos , resultBuf, 0, 2); //resultCode

        return new String(resultBuf);   // return the Response Code
    }

    public static LinkedHashMap<String, String> ifmPacketParsing(byte[] recvPacket){

        if(recvPacket == null){
            return null;
        }

        byte trdtype = recvPacket[IfmMakePkt.RdiFormat.STX_LEN+IfmMakePkt.RdiFormat.DATA_LENGTH_LEN];
        int scrPos = IfmMakePkt.RdiFormat.STX_LEN+IfmMakePkt.RdiFormat.DATA_LENGTH_LEN;
        String resultCode = getRespCode(recvPacket);
        byte[] recvPktData = new byte[recvPacket.length - scrPos];

        System.arraycopy(recvPacket,scrPos,recvPktData,0, recvPktData.length);

        mCallbackMap = new LinkedHashMap<>();

        switch(trdtype){
            case TRD_TYPE_REQ_SELF_PROTECTION:{
                mCallbackMap.put(MapData.Mapkey_A1[0],resultCode.equals("00") == false ? "무결성 검증실패" : "무결성 검증성공");
                break;
            }
            case 0x0A:{     //FW Information
                byte [] fwVer = new byte[16];
                byte[] buildDate = new byte[11];
                byte[] buildType = new byte[11];

                System.arraycopy(recvPacket, 6, fwVer, 0, fwVer.length);
                System.arraycopy(recvPacket, 22, buildDate, 0, buildDate.length);
                System.arraycopy(recvPacket, 33, buildType, 0, buildType.length);

                mCallbackMap.put(MapData.Mapkey_0A[0],new String(fwVer));
                mCallbackMap.put(MapData.Mapkey_0A[1],new String(buildDate));
                mCallbackMap.put(MapData.Mapkey_0A[2],new String(buildType));
                break;
            }
        }

        return mCallbackMap;
    }
}
