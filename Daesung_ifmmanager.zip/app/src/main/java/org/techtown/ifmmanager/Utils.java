package org.techtown.ifmmanager;


public class Utils {
    public static boolean m_fRdiOn = false;

    public static final int SDK_KCP  = 1;
    public static int SDK_VAN = SDK_KCP;

    public static final int IFM_RESP_RECEIVE_OK         = 10;
    public static final int IFM_RESP_RECEIVE_FAIL       = 11;
    public static final int IFM_RESP_RECEIVE_TIMEOUT    = 12;

    public static final int MAX_ICREADER_PACKET_SIZE    = 2560;

    /**<
     * format : STX | HL | LL | trdType | ~ | ETX | LRC
     * @param len : 2Byte value (HL | LL or LL | HL)
     * @return : length of integer value
     */
    public static int checkLength(byte[] len) {

        StringBuffer    sb = new StringBuffer(len.length * 2);
        String          hexaDecimal;

        for (int x = 0; x < len.length; x++) {
            hexaDecimal = "0" + Integer.toHexString(0xff & len[x]);
            sb.append(hexaDecimal.substring(hexaDecimal.length() - 2));
        }

        int     decimal = Integer.parseInt(sb.toString(), 16);

        return decimal;//(int) ((HL << 8) | LL) + 4 ;
    }
}
