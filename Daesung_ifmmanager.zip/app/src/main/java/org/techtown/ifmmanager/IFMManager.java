package org.techtown.ifmmanager;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import java.util.Arrays;

public class IFMManager implements IFMControllerInterface.OnIFMControllerInterface {

    private final String TAG = IFMManager.class.getSimpleName();

    private Context mContext = null;
    public static RdiManager mRdiManager;
    private boolean     m_fRdiOn=false;

    private IFMControllerInterface.OnIfmRecvCallback       mIfmRcvCallback;

    public IFMManager(){
        Utils.m_fRdiOn = false;

        if(mRdiManager == null) {
            mRdiManager = new RdiManager();
        }
    }

    public IFMManager(Context context){
        Utils.m_fRdiOn = false;
        mContext = context;

        if(mRdiManager == null) {
            mRdiManager = new RdiManager();
        }
    }

    private boolean onRdi(){
        if(mRdiManager == null)
            mRdiManager = new RdiManager(mContext);

        if(mRdiManager != null){
            mRdiManager.rdiSetEnable(mRdiManager.DISABLE);
            mRdiManager.powerDown();
            mRdiManager.powerOn();
            m_fRdiOn = true;
        }

        return mRdiManager.mIsRdiOpened;
    }

    private void offRdi(){
        if(mRdiManager != null){
            if(mRdiManager.isEnabled() == mRdiManager.ENABLE){
                mRdiManager.setEnable(mRdiManager.DISABLE);
            }

            mRdiManager.powerDown();
        }

        return;
    }

    private void setupRdi() {

        onRdi();

        if (mRdiManager != null) {
            if (mRdiManager.isEnabled() != mRdiManager.ENABLE) {
                mRdiManager.setEnable(mRdiManager.ENABLE);
            }
        }

        return;
    }

    @Override
    public void PowerOnRdi() {
        onRdi();
    }

    @Override
    public void PowerOffRdi(){
        offRdi();
    }

    @Override
    public void initIfmController(Context context, IFMControllerInterface.OnIfmRecvCallback ifmRecvCallback){
        mContext = context;

        if(mRdiManager == null){
            mRdiManager = new RdiManager(context);
        }

        mIfmRcvCallback = ifmRecvCallback;
        return;
    }

    @Override
    public void reqIFM(byte trdType){

        byte[] rdPktBuf = null;
        int     rcvTimeout = 3000;
        
        switch(Utils.SDK_VAN){
            case Utils.SDK_KCP:
                IfmMakePkt ifmMakePkt = new IfmMakePkt(mContext);
                rdPktBuf = ifmMakePkt.makeICReaderPacket(trdType);
                rcvTimeout = 7000;
                break;
        }

        sendDataToMSR(rdPktBuf,rdPktBuf.length,rcvTimeout);
    }

    private void sendDataToMSR(byte[] rdPkt, int size, int timeout) {

        setupRdi();
        mRdiManager.clear();

        int     result = mRdiManager.write(rdPkt, size);

        if (mRdiManager != null && mRdiManager.isEnabled() == 1) {
            mRdiManager.readData(ifmManagerHandler, timeout);
        }

        return;
    }

    private void sendCallback(int callbackMsg, byte[] inputByte){
        mIfmRcvCallback.onIfmRecvCallback(callbackMsg,inputByte);

        if(inputByte != null){
            Arrays.fill(inputByte,(byte)0x00);
            Arrays.fill(inputByte,(byte)0xFF);
            Arrays.fill(inputByte,(byte)0x00);
        }
    }

    private Handler ifmManagerHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {

            switch (msg.what) {
                case Utils.IFM_RESP_RECEIVE_OK:

                    byte[]      rcvIfmPktBuf = (byte[]) msg.obj;        // heap memory 의 address 를 mapping 한다.

                    if (rcvIfmPktBuf == null) {
                        sendCallback(Utils.IFM_RESP_RECEIVE_FAIL, null);
                        break;
                    }
                    sendCallback(Utils.IFM_RESP_RECEIVE_OK, rcvIfmPktBuf);
                    break;

                case Utils.IFM_RESP_RECEIVE_FAIL:

                    sendCallback(Utils.IFM_RESP_RECEIVE_FAIL, null);
                    break;

                case Utils.IFM_RESP_RECEIVE_TIMEOUT:

                    sendCallback(Utils.IFM_RESP_RECEIVE_TIMEOUT, null);
                    break;
            }
        }
    };
}
