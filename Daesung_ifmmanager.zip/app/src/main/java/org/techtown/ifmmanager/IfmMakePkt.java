package org.techtown.ifmmanager;

import android.content.Context;

public class IfmMakePkt {

    public class RdiFormat{
        public static final int STX_LEN = 1;
        public static final int DATA_LENGTH_LEN = 2;
        public static final int COMMANDID_LEN = 1;
        public static final int ETX_LEN = 1;
        public static final int LRC_LEN = 1;

        public static final byte CMD_STX = (byte)0x02;
        public static final byte CMD_ETX = (byte)0x03;
    }

    public static byte calcLRC(byte[] pktArray, int srcLen, int destLen) {
        byte LRC = 0x00;

        for (int i = srcLen; i < destLen; i++) {
            LRC ^= pktArray[i];
        }

        return LRC;
    }

    private Context mContext;

    public IfmMakePkt(Context context){
        mContext = context;
    }

    public byte [] makeICReaderPacket( byte CommandID)
    {
        byte [] rdPktBuf = null;
        byte[]  dataBuf =null;
        int index;

        switch(CommandID){
            case IfmPkt.TRD_TYPE_REQ_SELF_PROTECTION:{
                dataBuf = new byte[]{(byte) IfmPkt.CMD_FS};
                rdPktBuf = makePacket(CommandID,dataBuf);
                break;
            }
            case IfmPkt.TRD_TYPE_REQ_FW_INFO:{
                rdPktBuf = makePacket(CommandID,dataBuf);
                break;
            }
        }

        return rdPktBuf;
    }

    public static byte[] makePacket(byte cmdId, byte[] data){
        if(data == null){
            data = new byte[]{};
        }

        byte[] pktBuff = new byte[6 + data.length]; //[stx+len+cmdid+etx+lrc] +[data]
        int HeaderLen = RdiFormat.STX_LEN + RdiFormat.DATA_LENGTH_LEN + RdiFormat.COMMANDID_LEN;
        int length = RdiFormat.COMMANDID_LEN + data.length + RdiFormat.ETX_LEN;

        pktBuff[0] = RdiFormat.CMD_STX;         // STX
        pktBuff[1] = (byte)(length >> 8);       // Length of High
        pktBuff[2] = (byte)length;              // Length of Low
        pktBuff[3] = cmdId;                     // CMD 구분코드

        for(int i  = 0; i <data.length ; i ++){
            pktBuff[HeaderLen +i ] = data[i];
        }

        pktBuff[HeaderLen + data.length] = RdiFormat.CMD_ETX;

        int srcLen = RdiFormat.STX_LEN;
        int destLen = pktBuff.length - 1 ;
        byte LRC = calcLRC(pktBuff,srcLen,destLen);

        pktBuff[pktBuff.length -1 ] = LRC;

        return pktBuff;
    }


}
